// Declare a couple of functions - no modules problems.

void FuncOne();

int FuncTwo(int arg);
